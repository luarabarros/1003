const User = require('../models/userModel');
exports.getAllusers = (req, res) => {
    User.getAllUsers((users) => {
        res.render('index', {users});
    });
};

exports.getUserById = (req, res) => {
    const userId = req.params.id;
    User.getUserById(userId, (user) =>{
        res.render('edit', {user});
    });
};

exports.getdeleteByUser = (req, res) => {
    const userId = req.params.id;
    User.getUserById(userId, (user) => {
        res.render('dell', { user});
    });

};

///exibir usuário antes de deletar
exports.getDeleteByUser = (req,res) => {
    const userId = req.params.id;
    User.getUserById(userId, (user) => {
        res.render('dell', {user});

    });
};

exports.addUser = (req, res) => {
    const newUser = {
        name: req.body.name,
        email: req.body.email,
    };
    User.addUser(newUser, () => {
        res.redirect('/')
    });
};

exports.updateUser = (req, res) => {
    const userId = req.params.id;
    const updateUser= {
        name: req.body.name,
        email: req.body.email,
    };
    
    User.updateUser(userId, updateUser, () => {
        res.redirect('/');
    });
};

exports.deleteUser = (req, res) => {
    const userId = req.params.id;
    User.deleteUser(userId, () => {
        res.redirect('/');
    });
};
